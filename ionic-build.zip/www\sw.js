// Service Worker for IP连接器 PWA
const CACHE_NAME = 'ip-connector-v1.0.0';
const STATIC_CACHE_URLS = [
  '/',
  '/启动页.html',
  '/WebView显示页.html',
  '/设置页.html',
  '/关于我们_帮助页.html',
  '/连接失败提示页.html',
  '/assets/static/uxbot/daisyui@5.css',
  '/assets/static/uxbot/tailwind-browser@4.js',
  '/assets/static/uxbot/daisyui-themes.css',
  '/assets/3/3.1.1/iconify.min.js',
  '/assets/static/uxbot/25_6/holder.js',
  '/manifest.json'
];

// 安装事件 - 缓存静态资源
self.addEventListener('install', event => {
  console.log('Service Worker: Installing...');
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => {
        console.log('Service Worker: Caching static files');
        return cache.addAll(STATIC_CACHE_URLS);
      })
      .then(() => {
        console.log('Service Worker: Installation complete');
        return self.skipWaiting();
      })
      .catch(error => {
        console.error('Service Worker: Installation failed', error);
      })
  );
});

// 激活事件 - 清理旧缓存
self.addEventListener('activate', event => {
  console.log('Service Worker: Activating...');
  event.waitUntil(
    caches.keys()
      .then(cacheNames => {
        return Promise.all(
          cacheNames.map(cacheName => {
            if (cacheName !== CACHE_NAME) {
              console.log('Service Worker: Deleting old cache', cacheName);
              return caches.delete(cacheName);
            }
          })
        );
      })
      .then(() => {
        console.log('Service Worker: Activation complete');
        return self.clients.claim();
      })
  );
});

// 拦截网络请求
self.addEventListener('fetch', event => {
  // 只处理GET请求
  if (event.request.method !== 'GET') {
    return;
  }

  // 跳过chrome-extension和其他非http请求
  if (!event.request.url.startsWith('http')) {
    return;
  }

  event.respondWith(
    caches.match(event.request)
      .then(response => {
        // 如果缓存中有，直接返回
        if (response) {
          console.log('Service Worker: Serving from cache', event.request.url);
          return response;
        }

        // 否则从网络获取
        console.log('Service Worker: Fetching from network', event.request.url);
        return fetch(event.request)
          .then(response => {
            // 检查响应是否有效
            if (!response || response.status !== 200 || response.type !== 'basic') {
              return response;
            }

            // 克隆响应，因为响应只能使用一次
            const responseToCache = response.clone();

            // 缓存HTML页面和静态资源
            if (event.request.url.includes('.html') || 
                event.request.url.includes('.css') || 
                event.request.url.includes('.js') ||
                event.request.url.includes('.json')) {
              caches.open(CACHE_NAME)
                .then(cache => {
                  cache.put(event.request, responseToCache);
                });
            }

            return response;
          })
          .catch(error => {
            console.error('Service Worker: Fetch failed', error);
            
            // 如果是HTML页面请求失败，返回离线页面
            if (event.request.destination === 'document') {
              return caches.match('/连接失败提示页.html');
            }
            
            throw error;
          });
      })
  );
});

// 处理推送通知（如果需要）
self.addEventListener('push', event => {
  console.log('Service Worker: Push received');
  
  const options = {
    body: event.data ? event.data.text() : 'IP连接器有新消息',
    icon: '/assets/icons/icon-192x192.png',
    badge: '/assets/icons/icon-72x72.png',
    vibrate: [100, 50, 100],
    data: {
      dateOfArrival: Date.now(),
      primaryKey: 1
    },
    actions: [
      {
        action: 'explore',
        title: '查看详情',
        icon: '/assets/icons/icon-192x192.png'
      },
      {
        action: 'close',
        title: '关闭',
        icon: '/assets/icons/icon-192x192.png'
      }
    ]
  };

  event.waitUntil(
    self.registration.showNotification('IP连接器', options)
  );
});

// 处理通知点击
self.addEventListener('notificationclick', event => {
  console.log('Service Worker: Notification clicked');
  
  event.notification.close();

  if (event.action === 'explore') {
    event.waitUntil(
      clients.openWindow('/WebView显示页.html')
    );
  } else if (event.action === 'close') {
    // 什么都不做，只是关闭通知
  } else {
    // 默认行为：打开应用
    event.waitUntil(
      clients.openWindow('/启动页.html')
    );
  }
});

// 处理后台同步（如果需要）
self.addEventListener('sync', event => {
  console.log('Service Worker: Background sync', event.tag);
  
  if (event.tag === 'background-sync') {
    event.waitUntil(
      // 在这里执行后台同步逻辑
      doBackgroundSync()
    );
  }
});

// 后台同步函数
function doBackgroundSync() {
  return new Promise((resolve, reject) => {
    // 这里可以添加需要后台同步的逻辑
    // 比如保存离线数据、检查连接状态等
    console.log('Service Worker: Performing background sync');
    resolve();
  });
}

// 处理消息传递
self.addEventListener('message', event => {
  console.log('Service Worker: Message received', event.data);
  
  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
  
  if (event.data && event.data.type === 'GET_VERSION') {
    event.ports[0].postMessage({ version: CACHE_NAME });
  }
});
