# IP连接器 - Ionic Appflow构建包

## 📱 项目信息
- **应用名称**: IP连接器
- **包名**: com.example.ipconnector
- **版本**: 1.0.0
- **平台**: Android
- **框架**: Cordova

## 🚀 使用Ionic Appflow构建APK

### 步骤1: 注册Ionic Appflow
1. 访问 https://ionicframework.com/appflow
2. 点击 "Sign Up" 注册免费账户
3. 验证邮箱地址

### 步骤2: 创建项目
1. 登录后点击 "Create App"
2. 选择 "Cordova" 项目类型
3. 输入项目名称: "IP连接器"
4. 选择 "Private" 或 "Public" 仓库

### 步骤3: 上传构建包
1. 在项目页面点击 "Builds"
2. 点击 "New Build"
3. 选择 "Android" 平台
4. 上传 `ionic-build.zip` 文件
5. 点击 "Start Build"

### 步骤4: 等待构建完成
- 构建通常需要5-15分钟
- 可以在构建页面查看进度
- 构建完成后会收到邮件通知

### 步骤5: 下载APK
1. 构建完成后点击 "Download"
2. 下载APK文件到本地
3. 传输到Android设备安装

## 📁 项目结构
```
ionic-build/
├── config.xml          # Cordova配置文件
├── package.json        # 项目依赖配置
└── www/               # 应用源代码
    ├── splash.html    # 启动页
    ├── manifest.json  # PWA配置
    ├── sw.js         # Service Worker
    └── assets/       # 静态资源
        ├── icons/    # 应用图标
        └── static/   # UI框架文件
```

## 🔧 应用功能
- ✅ IP地址连接管理
- ✅ 实时连接状态显示
- ✅ PWA功能支持
- ✅ 移动端优化界面
- ✅ 离线使用支持
- ✅ 推送通知功能

## 📱 系统要求
- Android 5.1+ (API Level 22+)
- 支持ARM和x86架构
- 网络连接权限
- 存储权限

## 🛠️ 自定义开发
如需修改应用，可以：
1. 编辑 `www/` 目录中的HTML文件
2. 修改 `config.xml` 中的配置
3. 替换 `www/assets/icons/` 中的图标
4. 重新打包上传到Ionic Appflow

## 📞 技术支持
- **邮箱**: 995755805@qq.com
- **问题反馈**: 通过应用内"关于我们"页面联系

## 📄 许可证
本项目采用MIT许可证。

---

**注意**: Ionic Appflow免费账户每月有构建次数限制，如需更多构建次数可升级到付费计划。
